
export type Language = 'en' | 'ar';

export interface Vehicle {
  plateNumber: string;
  driverName: string;
  lastOdometer?: string;
  lastFuel?: string;
  totalReports: number;
  lastLocation?: {
    lat: number;
    lng: number;
    timestamp: string;
  };
}

export interface WorkingHours {
  start: string; // "HH:MM"
  end: string;   // "HH:MM"
}

export interface CustomQuestion {
  id: string;
  textEn: string;
  textAr: string;
  type: 'photo' | 'boolean' | 'text';
  required: boolean;
}

export interface FleetMessage {
  id: string;
  targetPlate: string; // 'ALL' or specific plate
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface InspectionReport {
  id: string;
  timestamp: string;
  plateNumber: string;
  driverName: string;
  odometerPhoto: string;
  odometerReading?: string;
  fuelStatus: 'full' | 'half' | 'low';
  fuelPhoto: string;
  accidentOccurred: boolean;
  accidentPhoto?: string;
  customAnswers: Record<string, any>;
}

export type UserRole = 'driver' | 'manager';

export interface Translation {
  title: string;
  roleSelect: string;
  driverRole: string;
  managerRole: string;
  loginPlate: string;
  loginAction: string;
  errorInvalidPlate: string;
  stepOdometer: string;
  stepFuel: string;
  stepAccident: string;
  capturePhoto: string;
  submit: string;
  success: string;
  fuelFull: string;
  fuelHalf: string;
  fuelLow: string;
  accidentYes: string;
  accidentNo: string;
  dashboardTitle: string;
  addVehicle: string;
  editVehicle: string;
  deleteVehicle: string;
  exportExcel: string;
  recentReports: string;
  plateHeader: string;
  driverHeader: string;
  statusHeader: string;
  dateHeader: string;
  ocrAnalyzing: string;
  managerLoginTitle: string;
  passwordPlaceholder: string;
  invalidPassword: string;
  changePassword: string;
  newPassword: string;
  savePassword: string;
  passwordSaved: string;
  tabDashboard: string;
  tabReports: string;
  tabFleet: string;
  tabQuestions: string;
  tabMessages: string;
  tabSettings: string;
  addQuestion: string;
  sendMessage: string;
  targetPlate: string;
  allVehicles: string;
  pendingAlerts: string;
  dismiss: string;
  startInspection: string;
  companyNameLabel: string;
  updateCompany: string;
  companyUpdated: string;
  workingHoursLabel: string;
  startTime: string;
  endTime: string;
  locationActive: string;
  lastKnownLocation: string;
}

export const translations: Record<Language, Translation> = {
  en: {
    title: "LogiCheck Pro",
    roleSelect: "Access Portal",
    driverRole: "Driver App",
    managerRole: "Manager App",
    loginPlate: "Enter License Plate",
    loginAction: "Login",
    errorInvalidPlate: "Unauthorized plate number.",
    stepOdometer: "Odometer Verification",
    stepFuel: "Fuel Inspection",
    stepAccident: "Safety Check",
    capturePhoto: "Take Photo",
    submit: "Finalize Report",
    success: "Report Verified & Sent!",
    fuelFull: "Full",
    fuelHalf: "Half",
    fuelLow: "Low",
    accidentYes: "Damage Detected",
    accidentNo: "No Damage",
    dashboardTitle: "Fleet Control Center",
    addVehicle: "Register Vehicle",
    editVehicle: "Edit Vehicle",
    deleteVehicle: "Delete",
    exportExcel: "Export Data",
    recentReports: "Live Inspection Feed",
    plateHeader: "Plate #",
    driverHeader: "Driver",
    statusHeader: "Status",
    dateHeader: "Time",
    ocrAnalyzing: "AI Scanner Active...",
    managerLoginTitle: "Secure Manager Login",
    passwordPlaceholder: "Passcode",
    invalidPassword: "Access Denied",
    changePassword: "Security Settings",
    newPassword: "New Passcode",
    savePassword: "Update",
    passwordSaved: "Updated Successfully",
    tabDashboard: "Analytics",
    tabReports: "Inspections",
    tabFleet: "Vehicles",
    tabQuestions: "Checklist",
    tabMessages: "Directives",
    tabSettings: "Settings",
    addQuestion: "Add Requirement",
    sendMessage: "Issue Alert",
    targetPlate: "Recipient Plate",
    allVehicles: "All Vehicles",
    pendingAlerts: "Important Manager Alerts",
    dismiss: "Acknowledge & Start",
    startInspection: "Proceed to Checklist",
    companyNameLabel: "Company Name",
    updateCompany: "Update Name",
    companyUpdated: "Name updated!",
    workingHoursLabel: "Official Working Hours",
    startTime: "Start Time",
    endTime: "End Time",
    locationActive: "Live Tracking Active",
    lastKnownLocation: "Last Known Location"
  },
  ar: {
    title: "لوجي تشيك برو",
    roleSelect: "بوابة الدخول",
    driverRole: "تطبيق السائق",
    managerRole: "تطبيق المدير",
    loginPlate: "أدخل رقم لوحة السيارة",
    loginAction: "دخول",
    errorInvalidPlate: "رقم اللوحة غير مسجل في النظام.",
    stepOdometer: "توثيق عداد المسافة",
    stepFuel: "فحص مستوى الوقود",
    stepAccident: "فحص السلامة والحوادث",
    capturePhoto: "التقاط صورة",
    submit: "إرسال التقرير النهائي",
    success: "تم إرسال وتوثيق التقرير!",
    fuelFull: "ممتلئ",
    fuelHalf: "نصف",
    fuelLow: "منخفض",
    accidentYes: "يوجد أضرار/صدمات",
    accidentNo: "سليمة تماماً",
    dashboardTitle: "مركز تحكم الأسطول",
    addVehicle: "تسجيل سيارة جديدة",
    editVehicle: "تعديل بيانات المركبة",
    deleteVehicle: "حذف",
    exportExcel: "تصدير البيانات",
    recentReports: "سجل الفحوصات المباشر",
    plateHeader: "اللوحة",
    driverHeader: "السائق",
    statusHeader: "الحالة",
    dateHeader: "الوقت",
    ocrAnalyzing: "جاري المسح بالذكاء الاصطناعي...",
    managerLoginTitle: "دخول المدير الآمن",
    passwordPlaceholder: "كلمة المرور",
    invalidPassword: "فشل التحقق من الهوية",
    changePassword: "إعدادات الأمان",
    newPassword: "كلمة المرور الجديدة",
    savePassword: "تحديث",
    passwordSaved: "تم التحديث بنجاح",
    tabDashboard: "الإحصائيات",
    tabReports: "التقارير",
    tabFleet: "المركبات",
    tabQuestions: "النماذج",
    tabMessages: "التوجيهات",
    tabSettings: "الإعدادات",
    addQuestion: "إضافة سؤال فحص",
    sendMessage: "إصدار تنبيه",
    targetPlate: "لوحة السيارة المستهدفة",
    allVehicles: "جميع المركبات",
    pendingAlerts: "تنبيهات إدارية هامة",
    dismiss: "فهمت، ابدأ الفحص",
    startInspection: "متابعة الفحص",
    companyNameLabel: "اسم الشركة",
    updateCompany: "تحديث الاسم",
    companyUpdated: "تم تحديث الاسم!",
    workingHoursLabel: "ساعات العمل الرسمية",
    startTime: "وقت البدء",
    endTime: "وقت الانتهاء",
    locationActive: "التتبع المباشر نشط",
    lastKnownLocation: "آخر موقع معروف"
  }
};
