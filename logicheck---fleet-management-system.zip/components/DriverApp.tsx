
import React, { useState, useEffect, useRef } from 'react';
import { Language, translations, Vehicle, InspectionReport, CustomQuestion, FleetMessage, WorkingHours } from '../types';
import { analyzeOdometer } from '../services/geminiService';

interface DriverAppProps {
  lang: Language;
  authorizedVehicles: Vehicle[];
  customQuestions: CustomQuestion[];
  messages: FleetMessage[];
  workingHours: WorkingHours;
  onSubmitReport: (report: InspectionReport) => void;
  onUpdateLocation: (plate: string, lat: number, lng: number) => void;
  onFinish: () => void;
}

const DriverApp: React.FC<DriverAppProps> = ({ lang, authorizedVehicles, customQuestions, messages, workingHours, onSubmitReport, onUpdateLocation, onFinish }) => {
  const t = translations[lang];
  const [step, setStep] = useState<'login' | 'alerts' | 'odometer' | 'fuel' | 'accident' | 'custom' | 'submitting' | 'success'>('login');
  const [plate, setPlate] = useState('');
  const [currentDriver, setCurrentDriver] = useState<string>('');
  const [pendingMessages, setPendingMessages] = useState<FleetMessage[]>([]);
  const watchIdRef = useRef<number | null>(null);
  
  // Data State
  const [odometerPhoto, setOdometerPhoto] = useState('');
  const [odometerReading, setOdometerReading] = useState('');
  const [fuelStatus, setFuelStatus] = useState<'full' | 'half' | 'low'>('full');
  const [fuelPhoto, setFuelPhoto] = useState('');
  const [accidentOccurred, setAccidentOccurred] = useState<boolean>(false);
  const [accidentPhoto, setAccidentPhoto] = useState('');
  const [customAnswers, setCustomAnswers] = useState<Record<string, any>>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState('');

  const currentActiveStepIdx = ['odometer', 'fuel', 'accident', 'custom', 'submitting'].indexOf(step);

  // Check if current time is within working hours
  const isWithinWorkingHours = () => {
    const now = new Date();
    const currentStr = now.getHours().toString().padStart(2, '0') + ":" + now.getMinutes().toString().padStart(2, '0');
    return currentStr >= workingHours.start && currentStr <= workingHours.end;
  };

  useEffect(() => {
    if (plate && isWithinWorkingHours()) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          onUpdateLocation(plate.toUpperCase(), pos.coords.latitude, pos.coords.longitude);
        },
        (err) => console.error("Location error", err),
        { enableHighAccuracy: true }
      );
    }
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, [plate, workingHours]);

  const handleLogin = () => {
    const found = authorizedVehicles.find(v => v.plateNumber.toUpperCase() === plate.toUpperCase());
    if (found) {
      setCurrentDriver(found.driverName);
      const relevantMessages = messages.filter(m => m.targetPlate === 'ALL' || m.targetPlate === plate.toUpperCase());
      if (relevantMessages.length > 0) {
        setPendingMessages(relevantMessages);
        setStep('alerts');
      } else {
        setStep('odometer');
      }
      setError('');
    } else {
      setError(t.errorInvalidPlate);
    }
  };

  const capturePhoto = (setter: (val: string) => void, callback?: (val: string) => void) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment';
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = async (readerEvent) => {
          const base64 = readerEvent.target?.result as string;
          setter(base64);
          if (callback) callback(base64);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleOdometerCapture = async (base64: string) => {
    setIsAnalyzing(true);
    const reading = await analyzeOdometer(base64);
    setOdometerReading(reading);
    setIsAnalyzing(false);
  };

  const handleFinalSubmit = async () => {
    setStep('submitting');
    const report: InspectionReport = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      plateNumber: plate.toUpperCase(),
      driverName: currentDriver,
      odometerPhoto,
      odometerReading,
      fuelStatus,
      fuelPhoto,
      accidentOccurred,
      accidentPhoto,
      customAnswers
    };
    onSubmitReport(report);
    setStep('success');
  };

  if (step === 'login') {
    return (
      <div className="max-w-md mx-auto bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 mt-8 animate-fade-in">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-lg shadow-blue-200">
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" /></svg>
        </div>
        <h3 className="text-2xl font-black mb-8 text-center text-slate-800">{t.loginPlate}</h3>
        <input 
          type="text" 
          placeholder="XYZ-123"
          className="w-full p-5 text-center text-3xl font-mono font-black border-2 border-slate-100 rounded-3xl focus:border-blue-600 focus:outline-none mb-6 uppercase bg-slate-50 transition-all"
          value={plate}
          onChange={(e) => setPlate(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
        />
        {error && <p className="text-red-500 text-sm mb-6 text-center font-bold animate-shake">{error}</p>}
        <button 
          onClick={handleLogin}
          className="w-full bg-blue-600 text-white py-5 rounded-3xl font-black text-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
        >
          {t.loginAction}
        </button>
      </div>
    );
  }

  if (step === 'alerts') {
    return (
      <div className="max-w-md mx-auto bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 mt-8 animate-fade-in text-center">
        <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
           <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
        </div>
        <h3 className="text-2xl font-black mb-6 text-slate-800">{t.pendingAlerts}</h3>
        <div className="space-y-4 mb-8">
           {pendingMessages.map(m => (
             <div key={m.id} className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 font-bold text-lg text-right">
                {m.message}
             </div>
           ))}
        </div>
        <button 
          onClick={() => setStep('odometer')}
          className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black text-xl hover:bg-black transition-all shadow-lg active:scale-95"
        >
          {t.dismiss}
        </button>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="text-center py-16 bg-white rounded-[3rem] shadow-xl border border-slate-100 animate-fade-in max-w-md mx-auto mt-12">
        <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7" /></svg>
        </div>
        <h3 className="text-3xl font-black text-slate-800 mb-4">{t.success}</h3>
        <p className="text-slate-500 font-medium mb-10 px-8 leading-relaxed">Great work, {currentDriver}. Shift data is now synced. Drive safely!</p>
        <button 
          onClick={onFinish}
          className="px-12 py-5 bg-blue-600 text-white rounded-[2rem] font-black text-xl hover:bg-blue-700 shadow-xl shadow-blue-200 transition-all active:scale-95"
        >
          {lang === 'ar' ? 'العودة للرئيسية' : 'Return Home'}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="bg-white border border-slate-100 p-6 rounded-[2rem] flex justify-between items-center shadow-sm">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center">
              <svg className="w-6 h-6 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
           </div>
           <div>
             <p className="text-xs text-slate-400 font-black uppercase tracking-widest">{t.driverHeader}</p>
             <p className="font-black text-slate-800 text-lg">{currentDriver}</p>
             {isWithinWorkingHours() && <span className="text-[10px] font-black text-green-500 flex items-center gap-1">● {t.locationActive}</span>}
           </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-400 font-black uppercase tracking-widest">{t.plateHeader}</p>
          <p className="font-mono font-black text-blue-600 text-xl uppercase">{plate}</p>
        </div>
      </div>

      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 space-y-10">
        <div className="flex items-center justify-between px-6">
          {['odometer', 'fuel', 'accident', 'custom'].map((s, idx) => (
            <React.Fragment key={s}>
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black transition-all ${(step === s || (s === 'custom' && step === 'submitting')) ? 'bg-blue-600 text-white scale-125 shadow-lg shadow-blue-200' : (idx < currentActiveStepIdx ? 'bg-green-500 text-white' : 'bg-slate-100 text-slate-400')}`}>
                {idx + 1}
              </div>
              {idx < 3 && <div className={`h-1 flex-grow mx-2 rounded-full transition-all ${idx < currentActiveStepIdx ? 'bg-green-400' : 'bg-slate-100'}`}></div>}
            </React.Fragment>
          ))}
        </div>

        <div className="min-h-[300px] flex flex-col items-center justify-center py-4">
          {step === 'odometer' && (
            <div className="w-full space-y-8 animate-slide-up">
              <h4 className="text-2xl font-black text-center">{t.stepOdometer}</h4>
              <div className="relative group mx-auto w-full max-w-sm aspect-video bg-slate-50 rounded-[2rem] overflow-hidden border-4 border-dashed border-slate-200 flex items-center justify-center cursor-pointer hover:border-blue-400 transition-all hover:bg-blue-50/50" onClick={() => capturePhoto(setOdometerPhoto, handleOdometerCapture)}>
                {odometerPhoto ? (
                  <img src={odometerPhoto} alt="Odometer" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-slate-400 flex flex-col items-center gap-4">
                     <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center shadow-sm">
                        <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                     </div>
                     <span className="font-bold">{t.capturePhoto}</span>
                  </div>
                )}
              </div>
              {isAnalyzing && <p className="text-blue-600 text-sm font-black animate-pulse text-center">{t.ocrAnalyzing}</p>}
              {odometerReading && !isAnalyzing && (
                <div className="bg-blue-600 p-6 rounded-3xl text-center shadow-lg shadow-blue-200 animate-bounce-short mx-auto inline-block min-w-[200px] flex flex-col gap-1">
                  <span className="text-white/80 text-xs font-black uppercase">Verified Reading</span>
                  <span className="text-white text-3xl font-black font-mono">{odometerReading} km</span>
                </div>
              )}
              {odometerPhoto && <button onClick={() => setStep('fuel')} className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black text-xl hover:bg-black transition-all shadow-lg">{lang === 'ar' ? 'التالي' : 'Next'}</button>}
            </div>
          )}

          {step === 'fuel' && (
            <div className="w-full space-y-8 animate-slide-up">
              <h4 className="text-2xl font-black text-center">{t.stepFuel}</h4>
              <div className="flex gap-4 justify-center">
                {(['full', 'half', 'low'] as const).map((stat) => (
                  <button
                    key={stat}
                    onClick={() => setFuelStatus(stat)}
                    className={`flex-1 p-6 rounded-[1.5rem] font-black border-4 transition-all ${fuelStatus === stat ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-200 scale-105' : 'bg-white text-slate-500 border-slate-100 hover:border-slate-200'}`}
                  >
                    {stat === 'full' ? t.fuelFull : stat === 'half' ? t.fuelHalf : t.fuelLow}
                  </button>
                ))}
              </div>
              <div className="relative mx-auto w-full max-w-sm aspect-video bg-slate-50 rounded-[2rem] overflow-hidden border-4 border-dashed border-slate-200 flex items-center justify-center cursor-pointer" onClick={() => capturePhoto(setFuelPhoto)}>
                {fuelPhoto ? <img src={fuelPhoto} alt="Fuel" className="w-full h-full object-cover" /> : <div className="text-slate-400 font-bold">{t.capturePhoto}</div>}
              </div>
              {fuelPhoto && <button onClick={() => setStep('accident')} className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black text-xl hover:bg-black transition-all shadow-lg">{lang === 'ar' ? 'التالي' : 'Next'}</button>}
            </div>
          )}

          {step === 'accident' && (
            <div className="w-full space-y-8 animate-slide-up">
              <h4 className="text-2xl font-black text-center">{t.stepAccident}</h4>
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => setAccidentOccurred(true)}
                  className={`p-8 rounded-[2rem] font-black border-4 flex flex-col items-center gap-4 transition-all ${accidentOccurred ? 'bg-red-50 border-red-500 text-red-700 shadow-lg shadow-red-100' : 'bg-white border-slate-100 text-slate-400'}`}
                >
                  <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  {t.accidentYes}
                </button>
                <button
                  onClick={() => setAccidentOccurred(false)}
                  className={`p-8 rounded-[2rem] font-black border-4 flex flex-col items-center gap-4 transition-all ${!accidentOccurred ? 'bg-green-50 border-green-500 text-green-700 shadow-lg shadow-green-100' : 'bg-white border-slate-100 text-slate-400'}`}
                >
                  <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  {t.accidentNo}
                </button>
              </div>
              {accidentOccurred && (
                <div className="relative mx-auto w-full max-w-sm aspect-video bg-slate-50 rounded-[2rem] overflow-hidden border-4 border-dashed border-slate-200 flex items-center justify-center cursor-pointer" onClick={() => capturePhoto(setAccidentPhoto)}>
                  {accidentPhoto ? <img src={accidentPhoto} alt="Accident" className="w-full h-full object-cover" /> : <div className="text-slate-400 font-bold">{t.capturePhoto}</div>}
                </div>
              )}
              <button onClick={() => setStep('custom')} className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black text-xl shadow-lg">{lang === 'ar' ? 'التالي' : 'Next'}</button>
            </div>
          )}

          {(step === 'custom' || step === 'submitting') && (
            <div className="w-full space-y-8 animate-slide-up">
              <h4 className="text-2xl font-black text-center">{lang === 'ar' ? 'متطلبات إضافية' : 'Custom Requirements'}</h4>
              <div className="space-y-6">
                {customQuestions.length === 0 ? (
                  <p className="text-slate-400 text-center italic">{lang === 'ar' ? 'لا توجد أسئلة إضافية حالياً' : 'No custom questions configured'}</p>
                ) : (
                  customQuestions.map(q => (
                    <div key={q.id} className="p-6 bg-slate-50 rounded-[1.5rem] border border-slate-100">
                      <p className="font-black text-slate-800 mb-4 text-lg">{lang === 'ar' ? q.textAr : q.textEn}</p>
                      {q.type === 'boolean' && (
                        <div className="flex gap-4">
                          <button onClick={() => setCustomAnswers(prev => ({ ...prev, [q.id]: true }))} className={`flex-1 py-4 rounded-2xl font-black border-2 ${customAnswers[q.id] === true ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200'}`}>Yes</button>
                          <button onClick={() => setCustomAnswers(prev => ({ ...prev, [q.id]: false }))} className={`flex-1 py-4 rounded-2xl font-black border-2 ${customAnswers[q.id] === false ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-500 border-slate-200'}`}>No</button>
                        </div>
                      )}
                      {q.type === 'photo' && (
                        <div className="aspect-video bg-white rounded-2xl border-2 border-dashed border-slate-200 flex items-center justify-center cursor-pointer overflow-hidden" onClick={() => capturePhoto(val => setCustomAnswers(prev => ({ ...prev, [q.id]: val })))}>
                          {customAnswers[q.id] ? <img src={customAnswers[q.id]} className="w-full h-full object-cover" /> : <span className="text-slate-400 font-bold">{t.capturePhoto}</span>}
                        </div>
                      )}
                      {q.type === 'text' && (
                        <input type="text" onChange={(e) => setCustomAnswers(prev => ({ ...prev, [q.id]: e.target.value }))} className="w-full p-4 rounded-2xl border-2 border-slate-100 focus:border-blue-500 outline-none" placeholder="..." />
                      )}
                    </div>
                  ))
                )}
              </div>
              <button 
                onClick={handleFinalSubmit}
                disabled={step === 'submitting'}
                className="w-full bg-blue-600 text-white py-5 rounded-3xl font-black text-xl hover:bg-blue-700 transition-all shadow-lg flex items-center justify-center gap-3"
              >
                {step === 'submitting' && <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin"></div>}
                {t.submit}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DriverApp;
