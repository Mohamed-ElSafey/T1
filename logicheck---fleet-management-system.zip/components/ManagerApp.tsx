
import React, { useState } from 'react';
import { Language, translations, Vehicle, InspectionReport, CustomQuestion, FleetMessage, WorkingHours } from '../types';

interface ManagerAppProps {
  lang: Language;
  vehicles: Vehicle[];
  reports: InspectionReport[];
  questions: CustomQuestion[];
  messages: FleetMessage[];
  companyName: string;
  workingHours: WorkingHours;
  onAddVehicle: (v: Vehicle) => void;
  onEditVehicle: (plate: string, updated: Partial<Vehicle>) => void;
  onDeleteVehicle: (plate: string) => void;
  onSetQuestions: (qs: CustomQuestion[]) => void;
  onSetMessages: (ms: FleetMessage[]) => void;
  onSetCompanyName: (name: string) => void;
  onSetWorkingHours: (hours: WorkingHours) => void;
  onChangePassword: (newPass: string) => void;
}

const ManagerApp: React.FC<ManagerAppProps> = ({ lang, vehicles, reports, questions, messages, companyName, workingHours, onAddVehicle, onEditVehicle, onDeleteVehicle, onSetQuestions, onSetMessages, onSetCompanyName, onSetWorkingHours, onChangePassword }) => {
  const t = translations[lang];
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reports' | 'fleet' | 'questions' | 'messages' | 'settings'>('dashboard');
  const [viewingReport, setViewingReport] = useState<InspectionReport | null>(null);
  
  // Dashboard Metrics
  const totalReports = reports.length;
  const criticalReports = reports.filter(r => r.accidentOccurred).length;

  // Forms State
  const [newVehicle, setNewVehicle] = useState({ plate: '', driver: '' });
  const [editingVehiclePlate, setEditingVehiclePlate] = useState<string | null>(null);
  const [editVehicleData, setEditVehicleData] = useState({ plate: '', driver: '' });
  
  const [newMsg, setNewMsg] = useState({ plate: 'ALL', text: '' });
  const [newQ, setNewQ] = useState<Partial<CustomQuestion>>({ textEn: '', textAr: '', type: 'photo', required: true });

  // Settings State
  const [editCompanyName, setEditCompanyName] = useState(companyName);
  const [editWorkingHours, setEditWorkingHours] = useState(workingHours);
  const [newPassInput, setNewPassInput] = useState('');
  const [settingsMessage, setSettingsMessage] = useState('');

  const handleAddQuestion = () => {
    if (newQ.textEn && newQ.textAr) {
      onSetQuestions([...questions, { ...newQ, id: Math.random().toString(36).substr(2, 9) } as CustomQuestion]);
      setNewQ({ textEn: '', textAr: '', type: 'photo', required: true });
    }
  };

  const handleSendMessage = () => {
    if (newMsg.text) {
      onSetMessages([...messages, { 
        id: Math.random().toString(36).substr(2, 9), 
        targetPlate: newMsg.plate, 
        message: newMsg.text, 
        timestamp: new Date().toISOString(),
        isRead: false 
      }]);
      setNewMsg({ plate: 'ALL', text: '' });
    }
  };

  const handleUpdateSettings = () => {
    onSetCompanyName(editCompanyName);
    onSetWorkingHours(editWorkingHours);
    if (newPassInput.length >= 4) {
      onChangePassword(newPassInput);
    }
    setSettingsMessage(t.companyUpdated);
    setTimeout(() => setSettingsMessage(''), 3000);
  };

  const startEditing = (v: Vehicle) => {
    setEditingVehiclePlate(v.plateNumber);
    setEditVehicleData({ plate: v.plateNumber, driver: v.driverName });
  };

  const saveEdit = () => {
    if (editingVehiclePlate) {
      onEditVehicle(editingVehiclePlate, { plateNumber: editVehicleData.plate.toUpperCase(), driverName: editVehicleData.driver });
      setEditingVehiclePlate(null);
    }
  };

  const exportCSV = () => {
    const headers = ["ID", "Timestamp", "Plate", "Driver", "Odometer", "Fuel", "Accident"].join(',');
    const rows = reports.map(r => 
      [r.id, r.timestamp, r.plateNumber, r.driverName, r.odometerReading || 'N/A', r.fuelStatus, r.accidentOccurred ? 'YES' : 'NO'].join(',')
    );
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `fleet_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
           <h2 className="text-4xl font-black text-slate-900 tracking-tight">{t.dashboardTitle}</h2>
           <p className="text-slate-500 font-medium">Real-time logistics monitoring & compliance</p>
        </div>
        <div className="flex gap-2">
           <button onClick={exportCSV} className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-black hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center gap-2">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              {t.exportExcel}
           </button>
        </div>
      </div>

      <nav className="flex bg-white p-2 rounded-3xl shadow-sm border border-slate-100 overflow-x-auto gap-2">
        {(['dashboard', 'reports', 'fleet', 'questions', 'messages', 'settings'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 rounded-2xl font-black text-sm whitespace-nowrap transition-all ${activeTab === tab ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            {t[`tab${tab.charAt(0).toUpperCase() + tab.slice(1)}` as keyof typeof t]}
          </button>
        ))}
      </nav>

      <div className="animate-fade-in">
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Fleet Reports</p>
              <h4 className="text-4xl font-black text-slate-800">{totalReports}</h4>
              <div className="mt-4 h-1 bg-blue-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 w-3/4"></div>
              </div>
            </div>
            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
              <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Safety Alerts</p>
              <h4 className="text-4xl font-black text-red-600">{criticalReports}</h4>
              <p className="text-xs mt-2 font-bold text-red-400">Requires review</p>
            </div>

            <div className="md:col-span-2 bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100">
              <h3 className="text-xl font-black mb-6">Active Tracking & Activity</h3>
              <div className="space-y-4">
                {vehicles.filter(v => v.lastLocation).map(v => (
                  <div key={v.plateNumber} className="flex items-center justify-between p-4 bg-blue-50/50 rounded-2xl border border-blue-100 animate-pulse">
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center">
                           <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                        </div>
                        <div>
                          <p className="font-black text-blue-900">{v.driverName} ({v.plateNumber})</p>
                          <p className="text-[10px] font-bold text-blue-400 uppercase">Live: {v.lastLocation?.lat.toFixed(4)}, {v.lastLocation?.lng.toFixed(4)}</p>
                        </div>
                     </div>
                     <span className="text-[10px] font-black text-blue-600 bg-blue-100 px-2 py-1 rounded">ONLINE</span>
                  </div>
                ))}
                {reports.slice(0, 5).map(r => (
                  <div key={r.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold ${r.accidentOccurred ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                         {r.accidentOccurred ? '!' : '✓'}
                      </div>
                      <div>
                        <p className="font-black text-slate-800">{r.driverName}</p>
                        <p className="text-xs font-bold text-slate-400 uppercase">{r.plateNumber}</p>
                      </div>
                    </div>
                    <div className="text-right">
                       <p className="text-sm font-black">{r.odometerReading} km</p>
                       <p className="text-[10px] font-bold text-slate-400">{new Date(r.timestamp).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 text-slate-400 text-[10px] uppercase font-black tracking-widest">
                    <th className="px-8 py-4">{t.plateHeader}</th>
                    <th className="px-8 py-4">{t.driverHeader}</th>
                    <th className="px-8 py-4">{t.statusHeader}</th>
                    <th className="px-8 py-4">{t.dateHeader}</th>
                    <th className="px-8 py-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {reports.map(report => (
                    <tr key={report.id} className="hover:bg-slate-50/50 transition-colors group">
                      <td className="px-8 py-5 font-mono font-black text-blue-600">{report.plateNumber}</td>
                      <td className="px-8 py-5 font-bold text-slate-700">{report.driverName}</td>
                      <td className="px-8 py-5">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${report.fuelStatus === 'full' ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'}`}>
                          {report.fuelStatus}
                        </span>
                      </td>
                      <td className="px-8 py-5 text-sm font-bold text-slate-400">
                        {new Date(report.timestamp).toLocaleDateString()}
                      </td>
                      <td className="px-8 py-5 text-right">
                        <button onClick={() => setViewingReport(report)} className="bg-slate-100 group-hover:bg-blue-600 group-hover:text-white p-2 rounded-xl transition-all">
                           <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'fleet' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 h-fit">
              <h3 className="text-xl font-black mb-6">{editingVehiclePlate ? t.editVehicle : t.addVehicle}</h3>
              <div className="space-y-6">
                <div>
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">License Plate</label>
                  <input value={editingVehiclePlate ? editVehicleData.plate : newVehicle.plate} onChange={e => editingVehiclePlate ? setEditVehicleData({...editVehicleData, plate: e.target.value}) : setNewVehicle({...newVehicle, plate: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none transition-all uppercase font-mono font-bold" placeholder="ABC-123" />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">Driver Full Name</label>
                  <input value={editingVehiclePlate ? editVehicleData.driver : newVehicle.driver} onChange={e => editingVehiclePlate ? setEditVehicleData({...editVehicleData, driver: e.target.value}) : setNewVehicle({...newVehicle, driver: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none transition-all font-bold" placeholder="E.g. Khaled..." />
                </div>
                {editingVehiclePlate ? (
                  <div className="flex gap-2">
                    <button onClick={saveEdit} className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-black text-lg">Save Changes</button>
                    <button onClick={() => setEditingVehiclePlate(null)} className="flex-1 bg-slate-200 text-slate-700 py-4 rounded-2xl font-black text-lg">Cancel</button>
                  </div>
                ) : (
                  <button onClick={() => { if(newVehicle.plate && newVehicle.driver) { onAddVehicle({ plateNumber: newVehicle.plate.toUpperCase(), driverName: newVehicle.driver, totalReports: 0 }); setNewVehicle({plate:'', driver:''}); } }} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-blue-100">Register Vehicle</button>
                )}
              </div>
            </div>
            <div className="space-y-4">
               {vehicles.map(v => (
                 <div key={v.plateNumber} className="bg-white p-6 rounded-[1.5rem] shadow-sm border border-slate-100 flex justify-between items-center group hover:border-blue-200 transition-all">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold">{v.plateNumber.charAt(0)}</div>
                       <div>
                         <p className="font-black text-slate-800 uppercase font-mono">{v.plateNumber}</p>
                         <p className="text-xs font-bold text-slate-400">{v.driverName}</p>
                       </div>
                    </div>
                    <div className="flex items-center gap-2">
                       <button onClick={() => startEditing(v)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                       </button>
                       <button onClick={() => onDeleteVehicle(v.plateNumber)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                       </button>
                    </div>
                 </div>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'questions' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 h-fit">
               <h3 className="text-xl font-black mb-6">{t.addQuestion}</h3>
               <div className="space-y-6">
                 <div>
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">English Label</label>
                    <input value={newQ.textEn} onChange={e => setNewQ({...newQ, textEn: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none transition-all font-bold" />
                 </div>
                 <div>
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">Arabic Label (Arabic)</label>
                    <input value={newQ.textAr} onChange={e => setNewQ({...newQ, textAr: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none transition-all font-bold text-right" dir="rtl" />
                 </div>
                 <div className="grid grid-cols-3 gap-2">
                    {(['photo', 'boolean', 'text'] as const).map(type => (
                      <button key={type} onClick={() => setNewQ({...newQ, type})} className={`py-3 rounded-xl font-black text-xs uppercase border-2 transition-all ${newQ.type === type ? 'bg-blue-600 text-white border-blue-600' : 'bg-white border-slate-100 text-slate-400'}`}>
                        {type}
                      </button>
                    ))}
                 </div>
                 <button onClick={handleAddQuestion} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black text-lg">Add to Checklist</button>
               </div>
            </div>
            <div className="space-y-4">
               {questions.map(q => (
                 <div key={q.id} className="bg-white p-6 rounded-[1.5rem] shadow-sm border border-slate-100 flex justify-between items-center">
                    <div>
                       <p className="font-black text-slate-800">{q.textAr}</p>
                       <p className="text-xs font-bold text-slate-400 italic">{q.textEn}</p>
                    </div>
                    <div className="flex items-center gap-3">
                       <span className="px-3 py-1 bg-slate-100 rounded-lg text-[10px] font-black uppercase text-slate-500">{q.type}</span>
                       <button onClick={() => onSetQuestions(questions.filter(x => x.id !== q.id))} className="text-red-300 hover:text-red-500 transition-colors">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                       </button>
                    </div>
                 </div>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 h-fit">
               <h3 className="text-xl font-black mb-6">{t.sendMessage}</h3>
               <div className="space-y-6">
                 <div>
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">{t.targetPlate}</label>
                    <select value={newMsg.plate} onChange={e => setNewMsg({...newMsg, plate: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold">
                       <option value="ALL">📢 {t.allVehicles}</option>
                       {vehicles.map(v => <option key={v.plateNumber} value={v.plateNumber}>{v.plateNumber} ({v.driverName})</option>)}
                    </select>
                 </div>
                 <div>
                    <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">Message Content</label>
                    <textarea value={newMsg.text} onChange={e => setNewMsg({...newMsg, text: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold h-32" placeholder="Write warning or instruction..." />
                 </div>
                 <button onClick={handleSendMessage} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-black text-lg shadow-lg shadow-blue-100">Broadcast Alert</button>
               </div>
            </div>
            <div className="space-y-4">
               {messages.map(m => (
                 <div key={m.id} className="bg-white p-6 rounded-[1.5rem] shadow-sm border border-slate-100">
                    <div className="flex justify-between items-start mb-2">
                       <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase ${m.targetPlate === 'ALL' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'}`}>
                          {m.targetPlate === 'ALL' ? 'BROADCAST' : m.targetPlate}
                       </span>
                       <button onClick={() => onSetMessages(messages.filter(x => x.id !== m.id))} className="text-slate-300 hover:text-red-500"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
                    </div>
                    <p className="font-bold text-slate-700">{m.message}</p>
                    <p className="text-[10px] font-bold text-slate-400 mt-3">{new Date(m.timestamp).toLocaleString()}</p>
                 </div>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-2xl mx-auto bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100">
             <h3 className="text-2xl font-black mb-8">{t.tabSettings}</h3>
             <div className="space-y-8">
                <div>
                   <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">{t.companyNameLabel}</label>
                   <input 
                     value={editCompanyName} 
                     onChange={e => setEditCompanyName(e.target.value)} 
                     className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold transition-all"
                   />
                </div>
                <div>
                   <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">{t.workingHoursLabel}</label>
                   <div className="flex gap-4">
                      <div className="flex-1">
                         <span className="text-[10px] font-black text-slate-400 uppercase">{t.startTime}</span>
                         <input type="time" value={editWorkingHours.start} onChange={e => setEditWorkingHours({...editWorkingHours, start: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold" />
                      </div>
                      <div className="flex-1">
                         <span className="text-[10px] font-black text-slate-400 uppercase">{t.endTime}</span>
                         <input type="time" value={editWorkingHours.end} onChange={e => setEditWorkingHours({...editWorkingHours, end: e.target.value})} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold" />
                      </div>
                   </div>
                </div>
                <div>
                   <label className="text-xs font-black text-slate-400 uppercase tracking-widest mb-2 block">{t.newPassword}</label>
                   <input 
                     type="password"
                     value={newPassInput} 
                     onChange={e => setNewPassInput(e.target.value)} 
                     className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-blue-600 rounded-2xl outline-none font-bold transition-all"
                     placeholder="Enter at least 4 characters"
                   />
                </div>
                {settingsMessage && <p className="text-green-600 font-bold text-center animate-pulse">{settingsMessage}</p>}
                <button 
                  onClick={handleUpdateSettings} 
                  className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black text-lg hover:bg-black transition-all shadow-lg active:scale-95"
                >
                  {t.savePassword}
                </button>
             </div>
          </div>
        )}
      </div>

      {viewingReport && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] w-full max-w-4xl max-h-[90vh] overflow-y-auto p-10 shadow-2xl animate-scale-in">
            <div className="flex justify-between items-start mb-10">
              <div className="flex items-center gap-6">
                <div className={`w-20 h-20 rounded-3xl flex items-center justify-center shadow-inner ${viewingReport.accidentOccurred ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                   <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <div>
                  <h3 className="text-3xl font-black text-slate-800 tracking-tight">Inspection Review</h3>
                  <p className="text-slate-400 font-bold uppercase tracking-widest text-xs mt-1">{new Date(viewingReport.timestamp).toLocaleString()}</p>
                </div>
              </div>
              <button onClick={() => setViewingReport(null)} className="p-4 bg-slate-100 hover:bg-slate-200 rounded-2xl transition-all">
                <svg className="w-6 h-6 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-8">
                <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Core Telemetry</h4>
                  <div className="flex items-end gap-2 mb-4">
                     <span className="text-5xl font-black text-slate-800 font-mono tracking-tighter">{viewingReport.odometerReading}</span>
                     <span className="text-xl font-black text-slate-400 uppercase mb-1">km</span>
                  </div>
                  <img src={viewingReport.odometerPhoto} className="w-full aspect-video object-cover rounded-2xl border-4 border-white shadow-sm" />
                </div>
                
                <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Fuel Compliance</h4>
                  <div className="flex items-center gap-3 mb-4">
                     <div className={`w-3 h-3 rounded-full ${viewingReport.fuelStatus === 'full' ? 'bg-green-500' : 'bg-amber-500'}`}></div>
                     <span className="text-2xl font-black text-slate-800 capitalize">{viewingReport.fuelStatus}</span>
                  </div>
                  <img src={viewingReport.fuelPhoto} className="w-full aspect-video object-cover rounded-2xl border-4 border-white shadow-sm" />
                </div>
              </div>
              
              <div className="space-y-8">
                <div className={`p-8 rounded-[2rem] border-4 ${viewingReport.accidentOccurred ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}>
                   <h4 className={`text-xs font-black uppercase tracking-widest mb-4 ${viewingReport.accidentOccurred ? 'text-red-500' : 'text-green-500'}`}>Safety Analysis</h4>
                   <p className="text-2xl font-black mb-4">{viewingReport.accidentOccurred ? '⚠️ Accident / Damage Reported' : '✅ Vehicle Clean'}</p>
                   {viewingReport.accidentPhoto ? (
                     <img src={viewingReport.accidentPhoto} className="w-full aspect-video object-cover rounded-2xl border-4 border-white shadow-sm" />
                   ) : <div className="p-8 bg-white/50 rounded-2xl text-center italic text-slate-400">No damage photos provided</div>}
                </div>

                <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100">
                  <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Extended Checklist Answers</h4>
                  <div className="space-y-4">
                    {Object.entries(viewingReport.customAnswers || {}).length === 0 ? (
                      <p className="text-slate-400 italic font-bold">No custom fields captured</p>
                    ) : (
                      Object.entries(viewingReport.customAnswers).map(([qid, val]) => {
                        const question = questions.find(q => q.id === qid);
                        return (
                          <div key={qid} className="flex flex-col gap-2">
                            <p className="text-sm font-black text-slate-700">{lang === 'ar' ? question?.textAr : question?.textEn}</p>
                            {typeof val === 'string' && val.startsWith('data:image') ? (
                              <img src={val} className="w-full aspect-video object-cover rounded-xl border border-slate-200" />
                            ) : (
                              <p className="p-3 bg-white rounded-xl font-bold border border-slate-100">{String(val)}</p>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerApp;
