
import { GoogleGenAI, Type } from "@google/genai";

export const analyzeOdometer = async (base64Image: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { text: "Extract the exact numerical odometer reading from this vehicle dashboard image. Return ONLY the number. If not found, return 'Unknown'." },
            { inlineData: { mimeType: "image/jpeg", data: base64Image.split(',')[1] || base64Image } }
          ]
        }
      ],
      config: {
        temperature: 0.1,
      }
    });

    return response.text.trim();
  } catch (error) {
    console.error("AI Analysis failed", error);
    return "N/A";
  }
};

export const analyzeSafety = async (base64Image: string): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
          {
            parts: [
              { text: "Describe any visible damage or accidents on this vehicle. Be brief. If the car looks fine, say 'No visible damage'." },
              { inlineData: { mimeType: "image/jpeg", data: base64Image.split(',')[1] || base64Image } }
            ]
          }
        ],
        config: {
          temperature: 0.2,
        }
      });
  
      return response.text.trim();
    } catch (error) {
      console.error("AI Safety Analysis failed", error);
      return "Unknown";
    }
  };
