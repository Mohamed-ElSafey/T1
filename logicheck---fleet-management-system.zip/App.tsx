
import React, { useState, useEffect } from 'react';
import { Language, UserRole, translations, Vehicle, InspectionReport, CustomQuestion, FleetMessage, WorkingHours } from './types';
import DriverApp from './components/DriverApp';
import ManagerApp from './components/ManagerApp';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('ar');
  const [role, setRole] = useState<UserRole | null>(null);
  const [isManagerAuthenticated, setIsManagerAuthenticated] = useState(false);
  const [managerInputPass, setManagerInputPass] = useState('');
  const [managerError, setManagerError] = useState('');

  const [companyName, setCompanyName] = useState(() => localStorage.getItem('company_name') || 'LogiCheck Pro');
  const [managerPassword, setManagerPassword] = useState(() => localStorage.getItem('manager_password') || '122333');
  const [workingHours, setWorkingHours] = useState<WorkingHours>(() => {
    const saved = localStorage.getItem('working_hours');
    return saved ? JSON.parse(saved) : { start: "08:00", end: "17:00" };
  });
  
  const [authorizedVehicles, setAuthorizedVehicles] = useState<Vehicle[]>(() => {
    const saved = localStorage.getItem('authorized_vehicles');
    return saved ? JSON.parse(saved) : [
      { plateNumber: "123-ABC", driverName: "Ahmed Salem", totalReports: 0 },
      { plateNumber: "456-XYZ", driverName: "John Doe", totalReports: 0 }
    ];
  });
  
  const [reports, setReports] = useState<InspectionReport[]>(() => {
    const saved = localStorage.getItem('fleet_reports');
    return saved ? JSON.parse(saved) : [];
  });

  const [customQuestions, setCustomQuestions] = useState<CustomQuestion[]>(() => {
    const saved = localStorage.getItem('custom_questions');
    return saved ? JSON.parse(saved) : [];
  });

  const [fleetMessages, setFleetMessages] = useState<FleetMessage[]>(() => {
    const saved = localStorage.getItem('fleet_messages');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('authorized_vehicles', JSON.stringify(authorizedVehicles));
    localStorage.setItem('fleet_reports', JSON.stringify(reports));
    localStorage.setItem('manager_password', managerPassword);
    localStorage.setItem('company_name', companyName);
    localStorage.setItem('working_hours', JSON.stringify(workingHours));
    localStorage.setItem('custom_questions', JSON.stringify(customQuestions));
    localStorage.setItem('fleet_messages', JSON.stringify(fleetMessages));
  }, [authorizedVehicles, reports, managerPassword, companyName, workingHours, customQuestions, fleetMessages]);

  const addReport = (report: InspectionReport) => {
    setReports(prev => [report, ...prev]);
    setAuthorizedVehicles(prev => prev.map(v => 
      v.plateNumber === report.plateNumber 
        ? { ...v, totalReports: v.totalReports + 1, lastOdometer: report.odometerReading, lastFuel: report.fuelStatus }
        : v
    ));
  };

  const updateDriverLocation = (plate: string, lat: number, lng: number) => {
    setAuthorizedVehicles(prev => prev.map(v => 
      v.plateNumber === plate 
        ? { ...v, lastLocation: { lat, lng, timestamp: new Date().toISOString() } }
        : v
    ));
  };

  const handleEditVehicle = (oldPlate: string, updated: Partial<Vehicle>) => {
    setAuthorizedVehicles(prev => prev.map(v => 
      v.plateNumber === oldPlate ? { ...v, ...updated } : v
    ));
    // Also update reports to reflect new driver name if plate matches
    if (updated.driverName) {
      setReports(prev => prev.map(r => r.plateNumber === oldPlate ? { ...r, driverName: updated.driverName! } : r));
    }
  };

  const handleDeleteVehicle = (plate: string) => {
    setAuthorizedVehicles(prev => prev.filter(v => v.plateNumber !== plate));
  };

  const handleManagerLogin = () => {
    if (managerInputPass === managerPassword) {
      setIsManagerAuthenticated(true);
      setManagerError('');
    } else {
      setManagerError(translations[lang].invalidPassword);
    }
  };

  const t = translations[lang];
  const isRTL = lang === 'ar';

  return (
    <div className={`min-h-screen ${isRTL ? 'rtl' : ''} flex flex-col font-sans bg-slate-50 transition-colors duration-300`}>
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200">
             <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1-1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1" />
             </svg>
          </div>
          <h1 className="text-xl font-black text-slate-800 tracking-tight">{lang === 'ar' ? companyName : (companyName === 'LogiCheck Pro' ? t.title : companyName)}</h1>
        </div>
        
        <div className="flex gap-3">
          <button 
            onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
            className="px-4 py-2 text-sm font-bold text-slate-600 bg-slate-100 rounded-full hover:bg-slate-200 transition-all"
          >
            {lang === 'en' ? 'العربية' : 'EN'}
          </button>
          {role && (
            <button 
              onClick={() => { setRole(null); setIsManagerAuthenticated(false); setManagerInputPass(''); }}
              className="px-4 py-2 text-sm font-bold text-white bg-slate-800 rounded-full hover:bg-slate-900 transition-all shadow-md"
            >
              {lang === 'en' ? 'Exit' : 'خروج'}
            </button>
          )}
        </div>
      </header>

      <main className="flex-grow container mx-auto p-4 max-w-5xl">
        {!role ? (
          <div className="flex flex-col items-center justify-center py-24 animate-fade-in">
            <h2 className="text-3xl font-black mb-12 text-slate-900 text-center">{t.roleSelect}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-2xl">
              <button 
                onClick={() => setRole('driver')}
                className="flex flex-col items-start p-8 bg-white rounded-3xl shadow-xl shadow-slate-200/50 border-2 border-transparent hover:border-blue-500 transition-all group relative overflow-hidden"
              >
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                </div>
                <span className="font-black text-2xl text-slate-800">{t.driverRole}</span>
                <p className="mt-2 text-slate-500 text-sm">{lang === 'ar' ? 'قم بتوثيق حالة السيارة قبل التحرك' : 'Document vehicle status before your shift'}</p>
              </button>
              
              <button 
                onClick={() => setRole('manager')}
                className="flex flex-col items-start p-8 bg-white rounded-3xl shadow-xl shadow-slate-200/50 border-2 border-transparent hover:border-slate-800 transition-all group relative overflow-hidden"
              >
                <div className="w-16 h-16 bg-slate-100 text-slate-800 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                   <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                </div>
                <span className="font-black text-2xl text-slate-800">{t.managerRole}</span>
                <p className="mt-2 text-slate-500 text-sm">{lang === 'ar' ? 'إدارة الأسطول، الأسئلة، والتقارير' : 'Manage fleet, custom checks, and reports'}</p>
              </button>
            </div>
          </div>
        ) : role === 'driver' ? (
          <DriverApp 
            lang={lang} 
            authorizedVehicles={authorizedVehicles} 
            customQuestions={customQuestions}
            messages={fleetMessages}
            workingHours={workingHours}
            onSubmitReport={addReport} 
            onUpdateLocation={updateDriverLocation}
            onFinish={() => setRole(null)}
          />
        ) : !isManagerAuthenticated ? (
          <div className="max-w-md mx-auto bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200 border border-slate-100 animate-fade-in mt-12">
            <h3 className="text-2xl font-black mb-8 text-center text-slate-800">{t.managerLoginTitle}</h3>
            <div className="space-y-6">
              <input 
                type="password" 
                placeholder={t.passwordPlaceholder}
                className="w-full p-5 text-center text-2xl tracking-widest border-2 border-slate-100 rounded-3xl focus:border-blue-600 focus:outline-none bg-slate-50 transition-all"
                value={managerInputPass}
                onChange={(e) => setManagerInputPass(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleManagerLogin()}
                autoFocus
              />
              {managerError && <p className="text-red-500 text-sm text-center font-bold animate-shake">{managerError}</p>}
              <button 
                onClick={handleManagerLogin}
                className="w-full bg-blue-600 text-white py-5 rounded-3xl font-black text-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 active:scale-95"
              >
                {t.loginAction}
              </button>
            </div>
          </div>
        ) : (
          <ManagerApp 
            lang={lang} 
            vehicles={authorizedVehicles} 
            reports={reports}
            questions={customQuestions}
            messages={fleetMessages}
            companyName={companyName}
            workingHours={workingHours}
            onAddVehicle={(v) => setAuthorizedVehicles(prev => [...prev, v])}
            onEditVehicle={handleEditVehicle}
            onDeleteVehicle={handleDeleteVehicle}
            onSetQuestions={setCustomQuestions}
            onSetMessages={setFleetMessages}
            onSetCompanyName={setCompanyName}
            onSetWorkingHours={setWorkingHours}
            onChangePassword={setManagerPassword}
          />
        )}
      </main>
    </div>
  );
};

export default App;
